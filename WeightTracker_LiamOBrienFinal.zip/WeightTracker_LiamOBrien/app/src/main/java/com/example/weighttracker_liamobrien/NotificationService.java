package com.example.weighttracker_liamobrien;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.telephony.SmsManager;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import java.util.Calendar;

public class NotificationService extends Service {
    private static final String TAG = "NotificationService";
    private static final String CHANNEL_ID = "WeightTrackerChannel";
    private static final int NOTIFICATION_ID = 1;
    private static final long DAILY_INTERVAL = 24 * 60 * 60 * 1000; // 24 hours
    private static final long WEEKLY_INTERVAL = 7 * DAILY_INTERVAL;

    private NotificationManager notificationManager;
    private AlarmManager alarmManager;
    private WeightDbHelper dbHelper;

    @Override
    public void onCreate() {
        super.onCreate();
        notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        dbHelper = new WeightDbHelper(this);
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            switch (intent.getAction()) {
                case "SCHEDULE_DAILY":
                    scheduleDailyReminder();
                    break;
                case "SCHEDULE_WEEKLY":
                    scheduleWeeklySummary();
                    break;
                case "SEND_REMINDER":
                    sendWeightReminder();
                    break;
                case "SEND_SUMMARY":
                    sendWeeklySummary(intent.getStringExtra("userId"));
                    break;
            }
        }
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Weight Tracker Notifications",
                NotificationManager.IMPORTANCE_DEFAULT
            );
            channel.setDescription("Notifications for weight tracking reminders and summaries");
            notificationManager.createNotificationChannel(channel);
        }
    }

    private void scheduleDailyReminder() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 8); // 8 AM
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);

        if (calendar.getTimeInMillis() < System.currentTimeMillis()) {
            calendar.add(Calendar.DAY_OF_YEAR, 1);
        }

        Intent intent = new Intent(this, NotificationService.class);
        intent.setAction("SEND_REMINDER");
        PendingIntent pendingIntent = PendingIntent.getService(
            this,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        alarmManager.setRepeating(
            AlarmManager.RTC_WAKEUP,
            calendar.getTimeInMillis(),
            DAILY_INTERVAL,
            pendingIntent
        );

        Log.d(TAG, "Daily reminder scheduled for " + calendar.getTime());
    }

    private void scheduleWeeklySummary() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
        calendar.set(Calendar.HOUR_OF_DAY, 20); // 8 PM
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);

        if (calendar.getTimeInMillis() < System.currentTimeMillis()) {
            calendar.add(Calendar.WEEK_OF_YEAR, 1);
        }

        Intent intent = new Intent(this, NotificationService.class);
        intent.setAction("SEND_SUMMARY");
        PendingIntent pendingIntent = PendingIntent.getService(
            this,
            1,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        alarmManager.setRepeating(
            AlarmManager.RTC_WAKEUP,
            calendar.getTimeInMillis(),
            WEEKLY_INTERVAL,
            pendingIntent
        );

        Log.d(TAG, "Weekly summary scheduled for " + calendar.getTime());
    }

    private void sendWeightReminder() {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Weight Tracker Reminder")
            .setContentText("Don't forget to log your weight today!")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true);

        notificationManager.notify(NOTIFICATION_ID, builder.build());
        Log.d(TAG, "Weight reminder notification sent");
    }

    private void sendWeeklySummary(String userId) {
        if (userId == null) return;

        try {
            String stats = dbHelper.getWeightStatsAsJson(userId);
            // Parse stats and create a summary message
            String summaryMessage = createSummaryMessage(stats);

            // Send notification
            NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("Weekly Weight Summary")
                .setContentText(summaryMessage)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(summaryMessage))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true);

            notificationManager.notify(NOTIFICATION_ID + 1, builder.build());

            // Send SMS if enabled
            sendSMSSummary(summaryMessage);

            Log.d(TAG, "Weekly summary sent");
        } catch (Exception e) {
            Log.e(TAG, "Error sending weekly summary: " + e.getMessage(), e);
        }
    }

    private String createSummaryMessage(String statsJson) {
        try {
            org.json.JSONObject stats = new org.json.JSONObject(statsJson);
            double minWeight = stats.getDouble("minWeight");
            double maxWeight = stats.getDouble("maxWeight");
            double avgWeight = stats.getDouble("avgWeight");
            int entries = stats.getInt("totalEntries");

            return String.format(
                "Weekly Summary:\nEntries: %d\nAvg Weight: %.1f kg\nMin: %.1f kg\nMax: %.1f kg",
                entries, avgWeight, minWeight, maxWeight
            );
        } catch (Exception e) {
            Log.e(TAG, "Error creating summary message: " + e.getMessage(), e);
            return "Weekly Weight Summary Available";
        }
    }

    private void sendSMSSummary(String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            // Get phone number from preferences
            String phoneNumber = getSharedPreferences("WeightTracker", MODE_PRIVATE)
                .getString("phone_number", null);
            
            if (phoneNumber != null) {
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Log.d(TAG, "SMS summary sent to " + phoneNumber);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error sending SMS summary: " + e.getMessage(), e);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (dbHelper != null) {
            dbHelper.close();
        }
    }
} 