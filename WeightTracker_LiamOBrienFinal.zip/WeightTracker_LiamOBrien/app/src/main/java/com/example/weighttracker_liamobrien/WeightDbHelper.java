package com.example.weighttracker_liamobrien;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import org.json.JSONObject;

public class WeightDbHelper extends DatabaseHelper {
    private static final String TAG = "WeightDbHelper";

    // Table name and columns
    public static final String TABLE_WEIGHTS = "weights";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_WEIGHT = "weight";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_UNIT = "unit";
    public static final String COLUMN_NOTES = "notes";

    // SQL statements
    private static final String SQL_CREATE_WEIGHTS_TABLE =
        "CREATE TABLE IF NOT EXISTS " + TABLE_WEIGHTS + " (" +
        COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
        COLUMN_USERNAME + " TEXT NOT NULL, " +
        COLUMN_WEIGHT + " REAL NOT NULL, " +
        COLUMN_DATE + " INTEGER NOT NULL, " +
        COLUMN_UNIT + " TEXT NOT NULL, " +
        COLUMN_NOTES + " TEXT)";

    private static final String SQL_DELETE_WEIGHTS_TABLE =
        "DROP TABLE IF EXISTS " + TABLE_WEIGHTS;

    public WeightDbHelper(Context context) {
        super(context);
        SQLiteDatabase db = null;
        try {
            db = getWritableDatabase();
            db.execSQL(SQL_CREATE_WEIGHTS_TABLE);
            Log.d(TAG, "WeightDbHelper initialized and weights table created");
        } catch (Exception e) {
            Log.e(TAG, "Error initializing WeightDbHelper: " + e.getMessage(), e);
        } finally {
            if (db != null) {
                db.close();
            }
        }
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            super.onCreate(db);
            Log.d(TAG, "Creating weights table");
            db.execSQL(SQL_CREATE_WEIGHTS_TABLE);
            Log.d(TAG, "Weights table created successfully");
        } catch (Exception e) {
            Log.e(TAG, "Error creating weights table: " + e.getMessage(), e);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        try {
            super.onUpgrade(db, oldVersion, newVersion);
            Log.d(TAG, "Upgrading weights table");
            db.execSQL(SQL_DELETE_WEIGHTS_TABLE);
            db.execSQL(SQL_CREATE_WEIGHTS_TABLE);
            Log.d(TAG, "Weights table upgraded successfully");
        } catch (Exception e) {
            Log.e(TAG, "Error upgrading weights table: " + e.getMessage(), e);
        }
    }

    public long addWeight(String username, double weight, String unit, String notes) {
        SQLiteDatabase db = null;
        try {
            db = getWritableDatabase();
            
            ContentValues values = new ContentValues();
            values.put(COLUMN_USERNAME, username);
            values.put(COLUMN_WEIGHT, weight);
            values.put(COLUMN_DATE, System.currentTimeMillis());
            values.put(COLUMN_UNIT, unit);
            values.put(COLUMN_NOTES, notes);
            
            Log.d(TAG, "Adding weight entry: " + values.toString());
            
            long newRowId = db.insert(TABLE_WEIGHTS, null, values);
            if (newRowId == -1) {
                Log.e(TAG, "Failed to insert weight entry into database");
            } else {
                Log.d(TAG, "Successfully added weight entry with ID: " + newRowId);
            }
            return newRowId;
        } catch (Exception e) {
            Log.e(TAG, "Error adding weight entry: " + e.getMessage(), e);
            return -1;
        }
    }

    public boolean updateWeight(long id, String username, double weight, String unit, String notes) {
        SQLiteDatabase db = null;
        try {
            db = getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COLUMN_WEIGHT, weight);
            values.put(COLUMN_UNIT, unit);
            values.put(COLUMN_NOTES, notes);
            
            String selection = COLUMN_ID + " = ? AND " + COLUMN_USERNAME + " = ?";
            String[] selectionArgs = {String.valueOf(id), username};
            
            int count = db.update(TABLE_WEIGHTS, values, selection, selectionArgs);
            Log.d(TAG, "Updated weight entry, rows affected: " + count);
            return count > 0;
        } catch (Exception e) {
            Log.e(TAG, "Error updating weight entry: " + e.getMessage(), e);
            return false;
        }
    }

    public boolean deleteWeight(long id, String username) {
        SQLiteDatabase db = null;
        try {
            db = getWritableDatabase();
            String selection = COLUMN_ID + " = ? AND " + COLUMN_USERNAME + " = ?";
            String[] selectionArgs = {String.valueOf(id), username};
            
            int count = db.delete(TABLE_WEIGHTS, selection, selectionArgs);
            Log.d(TAG, "Deleted weight entry, rows affected: " + count);
            return count > 0;
        } catch (Exception e) {
            Log.e(TAG, "Error deleting weight entry: " + e.getMessage(), e);
            return false;
        }
    }

    public Cursor getWeightHistory(String username) {
        try {
            SQLiteDatabase db = getReadableDatabase();
            String[] columns = {
                COLUMN_ID,
                COLUMN_USERNAME,
                COLUMN_WEIGHT,
                COLUMN_DATE,
                COLUMN_UNIT,
                COLUMN_NOTES
            };
            
            String selection = COLUMN_USERNAME + " = ?";
            String[] selectionArgs = {username};
            String orderBy = COLUMN_DATE + " DESC";
            
            Cursor cursor = db.query(
                TABLE_WEIGHTS,
                columns,
                selection,
                selectionArgs,
                null,
                null,
                orderBy
            );
            
            Log.d(TAG, "Retrieved " + cursor.getCount() + " weight entries");
            return cursor;
        } catch (Exception e) {
            Log.e(TAG, "Error getting weight history: " + e.getMessage(), e);
            return null;
        }
    }

    public String getWeightStatsAsJson(String username) {
        Cursor cursor = null;
        try {
            cursor = getWeightHistory(username);
            JSONObject stats = new JSONObject();
            
            if (cursor != null && cursor.getCount() > 0) {
                double minWeight = Double.MAX_VALUE;
                double maxWeight = Double.MIN_VALUE;
                double totalWeight = 0;
                int count = 0;
                
                int weightColumnIndex = cursor.getColumnIndex(COLUMN_WEIGHT);
                int unitColumnIndex = cursor.getColumnIndex(COLUMN_UNIT);
                
                while (cursor.moveToNext()) {
                    double weight = cursor.getDouble(weightColumnIndex);
                    String unit = cursor.getString(unitColumnIndex);
                    
                    // Convert to kg for calculations if needed
                    if ("lbs".equalsIgnoreCase(unit)) {
                        weight = weight * 0.453592;
                    }
                    
                    minWeight = Math.min(minWeight, weight);
                    maxWeight = Math.max(maxWeight, weight);
                    totalWeight += weight;
                    count++;
                }
                
                stats.put("minWeight", minWeight);
                stats.put("maxWeight", maxWeight);
                stats.put("avgWeight", count > 0 ? totalWeight / count : 0);
                stats.put("totalEntries", count);
            } else {
                stats.put("minWeight", 0);
                stats.put("maxWeight", 0);
                stats.put("avgWeight", 0);
                stats.put("totalEntries", 0);
            }
            
            return stats.toString();
        } catch (Exception e) {
            Log.e(TAG, "Error generating weight stats: " + e.getMessage(), e);
            return "{}";
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    public void clearWeights() {
        try {
            SQLiteDatabase db = getWritableDatabase();
            db.execSQL(SQL_DELETE_WEIGHTS_TABLE);
            db.execSQL(SQL_CREATE_WEIGHTS_TABLE);
            Log.d(TAG, "Weights table cleared and recreated");
        } catch (Exception e) {
            Log.e(TAG, "Error clearing weights table: " + e.getMessage(), e);
        }
    }
}