package com.example.weighttracker_liamobrien;

import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.*;
import android.content.ContentValues;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import android.util.Log;

public class WeightTrackerActivity extends AppCompatActivity {
    private static final String TAG = "WeightTrackerActivity";
    private WeightDbHelper dbHelper;
    private ListView weightList;
    private Button addWeightButton;
    private RadioGroup unitSelector;
    private TextView emptyText;
    private SimpleCursorAdapter adapter;
    private boolean isKgSelected = true;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_weight_tracker);

            Log.d(TAG, "Initializing WeightTrackerActivity");

            // Get username from intent
            username = getIntent().getStringExtra("username");
            if (username == null) {
                Log.e(TAG, "No username provided");
                Toast.makeText(this, "Error: No user identified", Toast.LENGTH_LONG).show();
                finish();
                return;
            }

            Log.d(TAG, "Username from intent: " + username);

            // Initialize database helper
            dbHelper = new WeightDbHelper(this);

            // Initialize UI elements
            weightList = findViewById(R.id.weightList);
            addWeightButton = findViewById(R.id.addWeightButton);
            unitSelector = findViewById(R.id.unitSelector);
            emptyText = findViewById(R.id.emptyText);

            // Set up unit selector
            unitSelector.setOnCheckedChangeListener((group, checkedId) -> {
                isKgSelected = checkedId == R.id.kgRadio;
                refreshList();
            });

            // Set up the list adapter
            setupListAdapter();

            // Set up add weight button
            addWeightButton.setOnClickListener(v -> showAddWeightDialog());

            Log.d(TAG, "WeightTrackerActivity initialized successfully");
        } catch (Exception e) {
            Log.e(TAG, "Error in onCreate: " + e.getMessage(), e);
            Toast.makeText(this, "Error initializing activity: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void setupListAdapter() {
        try {
            Log.d(TAG, "Setting up list adapter");
            
            // Get weight entries for the current user
            Cursor weightCursor = dbHelper.getWeightHistory(username);
            
            if (weightCursor == null || weightCursor.getCount() == 0) {
                Log.d(TAG, "No weight entries found for user: " + username);
                emptyText.setVisibility(View.VISIBLE);
                weightList.setVisibility(View.GONE);
                if (weightCursor != null) weightCursor.close();
                return;
            }

            Log.d(TAG, "Found " + weightCursor.getCount() + " weight entries");
            emptyText.setVisibility(View.GONE);
            weightList.setVisibility(View.VISIBLE);

            // Create a SimpleCursorAdapter
            String[] from = new String[]{
                WeightDbHelper.COLUMN_WEIGHT,
                WeightDbHelper.COLUMN_DATE,
                WeightDbHelper.COLUMN_UNIT,
                WeightDbHelper.COLUMN_NOTES
            };
            
            int[] to = new int[]{
                R.id.weightText,
                R.id.dateText,
                R.id.unitText,
                R.id.notesText
            };

            adapter = new SimpleCursorAdapter(
                this,
                R.layout.weight_entry_item,
                weightCursor,
                from,
                to,
                0
            );

            // Set custom ViewBinder to format the data
            adapter.setViewBinder((view, cursor, columnIndex) -> {
                try {
                    if (view.getId() == R.id.weightText) {
                        TextView weightText = (TextView) view;
                        float weight = cursor.getFloat(cursor.getColumnIndex(WeightDbHelper.COLUMN_WEIGHT));
                        String unit = cursor.getString(cursor.getColumnIndex(WeightDbHelper.COLUMN_UNIT));
                        if ("lbs".equals(unit) && isKgSelected) {
                            weight = weight * 0.453592f; // Convert lbs to kg
                        } else if ("kg".equals(unit) && !isKgSelected) {
                            weight = weight * 2.20462f; // Convert kg to lbs
                        }
                        weightText.setText(String.format("%.1f %s", weight, isKgSelected ? "kg" : "lbs"));
                        return true;
                    } else if (view.getId() == R.id.dateText) {
                        TextView dateText = (TextView) view;
                        long timestamp = cursor.getLong(cursor.getColumnIndex(WeightDbHelper.COLUMN_DATE));
                        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault());
                        dateText.setText(sdf.format(new Date(timestamp)));
                        return true;
                    } else if (view.getId() == R.id.notesText) {
                        TextView notesText = (TextView) view;
                        String notes = cursor.getString(cursor.getColumnIndex(WeightDbHelper.COLUMN_NOTES));
                        if (notes != null && !notes.isEmpty()) {
                            notesText.setText(notes);
                            notesText.setVisibility(View.VISIBLE);
                        } else {
                            notesText.setVisibility(View.GONE);
                        }
                        return true;
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error in ViewBinder: " + e.getMessage(), e);
                }
                return false;
            });

            weightList.setAdapter(adapter);
            Log.d(TAG, "List adapter set up successfully");
        } catch (Exception e) {
            Log.e(TAG, "Error setting up list adapter: " + e.getMessage(), e);
            Toast.makeText(this, "Error loading weight entries: " + e.getMessage(), Toast.LENGTH_LONG).show();
            emptyText.setVisibility(View.VISIBLE);
            weightList.setVisibility(View.GONE);
        }
    }

    private void showAddWeightDialog() {
        try {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            LayoutInflater inflater = getLayoutInflater();
            View dialogView = inflater.inflate(R.layout.dialog_add_weight, null);
            
            EditText weightInput = dialogView.findViewById(R.id.weightInput);
            EditText notesInput = dialogView.findViewById(R.id.notesInput);
            TextView unitText = dialogView.findViewById(R.id.unitText);
            unitText.setText(isKgSelected ? "kg" : "lbs");

            builder.setView(dialogView)
                .setTitle("Add Weight Entry")
                .setPositiveButton("Add", null)
                .setNegativeButton("Cancel", null);

            AlertDialog dialog = builder.create();
            
            dialog.setOnShowListener(dialogInterface -> {
                Button button = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
                button.setOnClickListener(view -> {
                    String weightStr = weightInput.getText().toString().trim();
                    String notes = notesInput.getText().toString().trim();
                    
                    if (weightStr.isEmpty()) {
                        weightInput.setError("Please enter a weight value");
                        return;
                    }

                    try {
                        float weight = Float.parseFloat(weightStr);
                        if (weight <= 0) {
                            weightInput.setError("Weight must be greater than 0");
                            return;
                        }
                        if (weight > 1000) {
                            weightInput.setError("Weight value seems too high");
                            return;
                        }
                        
                        Log.d(TAG, String.format("Adding weight entry - Weight: %.1f %s, Notes: %s, Username: %s", 
                            weight, isKgSelected ? "kg" : "lbs", notes, username));
                        
                        // Add weight entry
                        long result = dbHelper.addWeight(
                            username,
                            (double)weight,  // Explicitly cast to double
                            isKgSelected ? "kg" : "lbs",
                            notes
                        );
                        
                        if (result != -1) {
                            Log.d(TAG, "Weight entry added successfully with ID: " + result);
                            Toast.makeText(WeightTrackerActivity.this, "Weight entry added successfully", Toast.LENGTH_SHORT).show();
                            dialog.dismiss();
                            refreshList();
                        } else {
                            Log.e(TAG, "Failed to add weight entry to database");
                            Toast.makeText(WeightTrackerActivity.this, "Failed to add weight entry", Toast.LENGTH_LONG).show();
                        }
                    } catch (NumberFormatException e) {
                        Log.e(TAG, "Error parsing weight value: " + e.getMessage());
                        weightInput.setError("Please enter a valid number");
                    } catch (Exception e) {
                        Log.e(TAG, "Error adding weight entry: " + e.getMessage(), e);
                        Toast.makeText(WeightTrackerActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
            });

            dialog.show();
            Log.d(TAG, "Add weight dialog shown");
        } catch (Exception e) {
            Log.e(TAG, "Error showing add weight dialog: " + e.getMessage(), e);
            Toast.makeText(this, "Error showing dialog: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void refreshList() {
        try {
            if (adapter != null) {
                Log.d(TAG, "Refreshing weight list");
                Cursor oldCursor = adapter.getCursor();
                Cursor newCursor = dbHelper.getWeightHistory(username);
                adapter.changeCursor(newCursor);
                if (oldCursor != null) oldCursor.close();
                
                boolean isEmpty = newCursor == null || newCursor.getCount() == 0;
                emptyText.setVisibility(isEmpty ? View.VISIBLE : View.GONE);
                weightList.setVisibility(isEmpty ? View.GONE : View.VISIBLE);
                
                Log.d(TAG, "List refreshed. Entry count: " + (newCursor != null ? newCursor.getCount() : 0));
            } else {
                setupListAdapter();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error refreshing list: " + e.getMessage(), e);
        }
    }

    @Override
    protected void onDestroy() {
        try {
            super.onDestroy();
            Log.d(TAG, "Cleaning up resources");
            if (adapter != null && adapter.getCursor() != null) {
                adapter.getCursor().close();
            }
            if (dbHelper != null) {
                dbHelper.close();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error in onDestroy: " + e.getMessage(), e);
        }
    }
} 