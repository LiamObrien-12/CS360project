package com.example.weighttracker_liamobrien;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.util.Log;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.regex.Pattern;
import android.database.Cursor;
import java.io.*;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String TAG = "DatabaseHelper";
    private static final String DATABASE_NAME = "weighttracker.db";
    private static final int DATABASE_VERSION = 1;

    // Users table
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";
    public static final String COLUMN_REMEMBER_ME = "remember_me";
    public static final String COLUMN_NOTIFICATION_PREF = "notification_pref";

    // Password requirements
    private static final int MIN_PASSWORD_LENGTH = 8;
    private static final Pattern PASSWORD_PATTERN = Pattern.compile(
        "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$"
    );

    private static final String SQL_CREATE_USERS_TABLE =
        "CREATE TABLE IF NOT EXISTS " + TABLE_USERS + " (" +
        COLUMN_USERNAME + " TEXT PRIMARY KEY, " +
        COLUMN_PASSWORD + " TEXT NOT NULL, " +
        COLUMN_REMEMBER_ME + " INTEGER DEFAULT 0, " +
        COLUMN_NOTIFICATION_PREF + " TEXT DEFAULT 'daily')";

    private static final String SQL_DELETE_USERS_TABLE =
        "DROP TABLE IF EXISTS " + TABLE_USERS;

    private Context context;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
        Log.d(TAG, "DatabaseHelper initialized with database: " + DATABASE_NAME);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            Log.d(TAG, "Creating users table");
            db.execSQL(SQL_CREATE_USERS_TABLE);
            Log.d(TAG, "Users table created successfully");
        } catch (Exception e) {
            Log.e(TAG, "Error creating users table: " + e.getMessage(), e);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        try {
            Log.d(TAG, "Upgrading database from " + oldVersion + " to " + newVersion);
            db.execSQL(SQL_DELETE_USERS_TABLE);
            onCreate(db);
        } catch (Exception e) {
            Log.e(TAG, "Error upgrading database: " + e.getMessage(), e);
        }
    }

    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            Log.e(TAG, "Error hashing password", e);
            return null;
        }
    }

    public boolean isValidPassword(String password) {
        if (password == null || password.length() < MIN_PASSWORD_LENGTH) {
            return false;
        }
        return PASSWORD_PATTERN.matcher(password).matches();
    }

    public long addUser(String username, String password) {
        SQLiteDatabase db = null;
        try {
            db = getWritableDatabase();
            
            ContentValues values = new ContentValues();
            values.put(COLUMN_USERNAME, username);
            values.put(COLUMN_PASSWORD, password);
            
            long newRowId = db.insert(TABLE_USERS, null, values);
            Log.d(TAG, "Added user with result: " + newRowId);
            return newRowId;
        } catch (Exception e) {
            Log.e(TAG, "Error adding user: " + e.getMessage(), e);
            return -1;
        }
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = getReadableDatabase();
            String[] columns = {COLUMN_USERNAME};
            String selection = COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?";
            String[] selectionArgs = {username, password};
            
            cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
            boolean exists = cursor != null && cursor.getCount() > 0;
            Log.d(TAG, "User check result: " + exists);
            return exists;
        } catch (Exception e) {
            Log.e(TAG, "Error checking user: " + e.getMessage(), e);
            return false;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    public void setRememberMe(String username, boolean remember) {
        try {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COLUMN_REMEMBER_ME, remember ? 1 : 0);
            int rows = db.update(TABLE_USERS, values, COLUMN_USERNAME + " = ?", 
                new String[]{username});
            Log.d(TAG, "Remember me updated for " + username + ". Rows affected: " + rows);
        } catch (Exception e) {
            Log.e(TAG, "Error setting remember me: " + e.getMessage(), e);
        }
    }

    public boolean isRemembered(String username) {
        try {
            SQLiteDatabase db = this.getReadableDatabase();
            String[] columns = {COLUMN_REMEMBER_ME};
            String selection = COLUMN_USERNAME + " = ?";
            String[] selectionArgs = {username};
            
            try (Cursor cursor = db.query(TABLE_USERS, columns, selection, 
                selectionArgs, null, null, null)) {
                if (cursor.moveToFirst()) {
                    boolean remembered = cursor.getInt(0) == 1;
                    Log.d(TAG, "Remember me status for " + username + ": " + remembered);
                    return remembered;
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error checking remember me: " + e.getMessage(), e);
        }
        return false;
    }

    public void exportToCSV(String username, String filepath) {
        try {
            File file = new File(filepath);
            FileWriter fw = new FileWriter(file);
            SQLiteDatabase db = this.getReadableDatabase();
            
            // Export user data (excluding password)
            Cursor cursor = db.query(TABLE_USERS, 
                new String[]{COLUMN_USERNAME, COLUMN_NOTIFICATION_PREF}, 
                COLUMN_USERNAME + " = ?", 
                new String[]{username}, 
                null, null, null);

            while (cursor.moveToNext()) {
                fw.append(cursor.getString(0));
                fw.append(",");
                fw.append(cursor.getString(1));
                fw.append("\n");
            }
            
            cursor.close();
            fw.close();
            Log.d(TAG, "Data exported successfully");
        } catch (Exception e) {
            Log.e(TAG, "Error exporting data: " + e.getMessage(), e);
        }
    }

    public void setNotificationPreference(String username, String preference) {
        try {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COLUMN_NOTIFICATION_PREF, preference);
            db.update(TABLE_USERS, values, COLUMN_USERNAME + " = ?", 
                new String[]{username});
        } catch (Exception e) {
            Log.e(TAG, "Error setting notification preference: " + e.getMessage(), e);
        }
    }
} 