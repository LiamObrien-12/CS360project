package com.example.weighttracker_liamobrien;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;

public class BootReceiver extends BroadcastReceiver {
    private static final String TAG = "BootReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction() != null && 
            intent.getAction().equals(Intent.ACTION_BOOT_COMPLETED)) {
            
            Log.d(TAG, "Boot completed, restoring notification schedules");
            
            SharedPreferences prefs = context.getSharedPreferences(
                "WeightTracker", Context.MODE_PRIVATE);
            
            // Check notification preferences
            String notificationPref = prefs.getString("notification_frequency", "none");
            
            // Restore appropriate schedules
            Intent serviceIntent = new Intent(context, NotificationService.class);
            
            if (notificationPref.equals("daily")) {
                serviceIntent.setAction("SCHEDULE_DAILY");
                context.startService(serviceIntent);
                Log.d(TAG, "Restored daily notifications");
            } else if (notificationPref.equals("weekly")) {
                serviceIntent.setAction("SCHEDULE_WEEKLY");
                context.startService(serviceIntent);
                Log.d(TAG, "Restored weekly notifications");
            }
        }
    }
} 