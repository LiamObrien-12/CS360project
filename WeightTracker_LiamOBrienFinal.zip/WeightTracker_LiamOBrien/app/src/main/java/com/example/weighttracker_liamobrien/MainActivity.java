package com.example.weighttracker_liamobrien;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private EditText usernameInput;
    private EditText passwordInput;
    private Button loginButton;
    private CheckBox smsPermissionCheckbox;
    private TextView createAccountText;
    private DatabaseHelper dbHelper;
    private static final int SMS_PERMISSION_REQUEST_CODE = 123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            // Initialize UI elements
            usernameInput = findViewById(R.id.usernameInput);
            passwordInput = findViewById(R.id.passwordInput);
            loginButton = findViewById(R.id.loginButton);
            smsPermissionCheckbox = findViewById(R.id.smsPermissionCheckbox);
            createAccountText = findViewById(R.id.createAccountText);

            // Initialize database helper
            dbHelper = new DatabaseHelper(this);

            // Set up text watchers for input validation
            TextWatcher loginWatcher = new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    // Enable login button only if both fields have text
                    String username = usernameInput.getText().toString();
                    String password = passwordInput.getText().toString();
                    loginButton.setEnabled(!username.trim().isEmpty() && !password.trim().isEmpty());
                }

                @Override
                public void afterTextChanged(Editable s) {}
            };

            usernameInput.addTextChangedListener(loginWatcher);
            passwordInput.addTextChangedListener(loginWatcher);

            // Set up login button click listener
            loginButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    attemptLogin();
                }
            });

            // Set up SMS permission checkbox listener
            smsPermissionCheckbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isChecked) {
                    requestSmsPermission();
                }
            });

            // Set up create account click listener
            createAccountText.setOnClickListener(v -> createNewAccount());

            Log.d(TAG, "MainActivity initialized successfully");
        } catch (Exception e) {
            Log.e(TAG, "Error in onCreate: " + e.getMessage(), e);
            Toast.makeText(this, "Error initializing app: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void attemptLogin() {
        try {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            // Validate input
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            Log.d(TAG, "Attempting login for user: " + username);

            // Check credentials in database
            if (dbHelper.checkUser(username, password)) {
                Log.d(TAG, "Login successful for user: " + username);
                Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();
                
                if (smsPermissionCheckbox.isChecked() && checkSmsPermission()) {
                    sendLoginNotification(username);
                }
                
                // Launch WeightTrackerActivity
                Intent intent = new Intent(this, WeightTrackerActivity.class);
                intent.putExtra("username", username);
                intent.putExtra("sms_enabled", smsPermissionCheckbox.isChecked());
                startActivity(intent);
                finish(); // Close login activity
            } else {
                Log.d(TAG, "Login failed for user: " + username);
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error in attemptLogin: " + e.getMessage(), e);
            Toast.makeText(this, "Login error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void createNewAccount() {
        try {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!dbHelper.isValidPassword(password)) {
                Toast.makeText(this, 
                    "Password must be at least 8 characters long and contain:\n" +
                    "- At least one uppercase letter\n" +
                    "- At least one lowercase letter\n" +
                    "- At least one number\n" +
                    "- At least one special character (@#$%^&+=)", 
                    Toast.LENGTH_LONG).show();
                return;
            }

            Log.d(TAG, "Creating account for user: " + username);

            // Attempt to create account
            Log.d(TAG, "Attempting to create account for username: " + username);
            long result = dbHelper.addUser(username, password);
            if (result != -1) {
                Log.d(TAG, "Account created successfully");
                Toast.makeText(MainActivity.this, "Account created successfully!", Toast.LENGTH_SHORT).show();
            } else {
                Log.e(TAG, "Failed to create account");
                Toast.makeText(MainActivity.this, "Failed to create account", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error in createNewAccount: " + e.getMessage(), e);
            Toast.makeText(this, "Account creation error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void requestSmsPermission() {
        try {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) 
                != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, 
                    new String[]{Manifest.permission.SEND_SMS}, 
                    SMS_PERMISSION_REQUEST_CODE);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error in requestSmsPermission: " + e.getMessage(), e);
        }
    }

    private boolean checkSmsPermission() {
        try {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) 
                == PackageManager.PERMISSION_GRANTED;
        } catch (Exception e) {
            Log.e(TAG, "Error in checkSmsPermission: " + e.getMessage(), e);
            return false;
        }
    }

    private void sendLoginNotification(String username) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            String message = "New login detected for user: " + username;
            // smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS notification would be sent (demo)", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e(TAG, "Error in sendLoginNotification: " + e.getMessage(), e);
            Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        try {
            super.onDestroy();
            if (dbHelper != null) {
                dbHelper.close();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error in onDestroy: " + e.getMessage(), e);
        }
    }
} 