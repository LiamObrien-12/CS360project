# Weight Tracker App

## Overview
Weight Tracker is an Android application that helps users track their weight over time with SMS notifications and data visualization capabilities.

## System Requirements
- Android 8.0 (API level 26) or higher
- Minimum 50MB storage space
- SMS permissions for notifications

## Required Permissions
- SMS_SEND: For sending weight tracking notifications
- INTERNET: For future data backup features
- READ_EXTERNAL_STORAGE & WRITE_EXTERNAL_STORAGE: For data export functionality

## Installation Instructions
1. Download the APK file
2. Enable "Install from Unknown Sources" in your Android settings
3. Open the APK file and follow installation prompts
4. Launch the app and create an account

## Features
- Secure user authentication
- Weight tracking with kg/lbs conversion
- SMS notifications for updates
- Data visualization
- Data export capabilities
- Backup/restore functionality

## User Guide

### Account Management
- Create a new account with a unique username
- Password requirements:
  - Minimum 8 characters
  - At least one uppercase letter
  - At least one number
  - At least one special character

### Weight Tracking
- Add new weight entries
- View history in list or graph format
- Edit or delete existing entries
- Export data to CSV
- Set weight goals and receive notifications

### SMS Notifications
- Enable/disable notifications
- Customize notification frequency
- Set goal achievement alerts
- Morning weigh-in reminders

### Data Management
- Export data to CSV
- Backup data to cloud (coming soon)
- Restore from backup
- Clear all data

## Troubleshooting
- If app crashes, clear app data and cache
- For login issues, use the "Forgot Password" feature
- If notifications aren't working, check SMS permissions

## Support
For support, please contact: [Your Contact Information]

## Version History
- v1.0.0: Initial release
- v1.1.0: Added data visualization
- v1.2.0: Added export functionality 